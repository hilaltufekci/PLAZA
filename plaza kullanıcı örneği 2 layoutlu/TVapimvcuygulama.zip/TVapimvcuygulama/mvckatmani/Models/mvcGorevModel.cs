﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvckatmani.Models
{
    public class mvcGorevModel
    {
        public int GörevNo { get; set; }
        
        public string GörevTanimi { get; set; }
        public string Vardiya { get; set; }
    }
}